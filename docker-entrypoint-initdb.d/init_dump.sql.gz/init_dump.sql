--
-- PostgreSQL database dump
--

-- Dumped from database version 10.4
-- Dumped by pg_dump version 10.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: api_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_item (
    id integer NOT NULL,
    created_on timestamp with time zone NOT NULL,
    updated_on timestamp with time zone NOT NULL,
    title character varying(75) NOT NULL,
    image_url character varying(300) NOT NULL,
    description character varying(300) NOT NULL,
    uuid character varying(75) NOT NULL,
    price numeric(8,2) NOT NULL,
    store_id integer NOT NULL
);


ALTER TABLE public.api_item OWNER TO postgres;

--
-- Name: api_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_item_id_seq OWNER TO postgres;

--
-- Name: api_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_item_id_seq OWNED BY public.api_item.id;


--
-- Name: api_store; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_store (
    id integer NOT NULL,
    created_on timestamp with time zone NOT NULL,
    updated_on timestamp with time zone NOT NULL,
    uuid character varying(75) NOT NULL,
    title character varying(75) NOT NULL,
    hero_image_url character varying(300) NOT NULL,
    location jsonb NOT NULL,
    city character varying(50) NOT NULL,
    currency character varying(3) NOT NULL
);


ALTER TABLE public.api_store OWNER TO postgres;

--
-- Name: api_store_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_store_categories (
    id integer NOT NULL,
    store_id integer NOT NULL,
    storecategory_id integer NOT NULL
);


ALTER TABLE public.api_store_categories OWNER TO postgres;

--
-- Name: api_store_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_store_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_store_categories_id_seq OWNER TO postgres;

--
-- Name: api_store_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_store_categories_id_seq OWNED BY public.api_store_categories.id;


--
-- Name: api_store_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_store_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_store_id_seq OWNER TO postgres;

--
-- Name: api_store_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_store_id_seq OWNED BY public.api_store.id;


--
-- Name: api_storecategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_storecategory (
    id integer NOT NULL,
    created_on timestamp with time zone NOT NULL,
    updated_on timestamp with time zone NOT NULL,
    name character varying(75) NOT NULL,
    key character varying(75) NOT NULL,
    uuid character varying(75) NOT NULL
);


ALTER TABLE public.api_storecategory OWNER TO postgres;

--
-- Name: api_storecategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_storecategory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.api_storecategory_id_seq OWNER TO postgres;

--
-- Name: api_storecategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_storecategory_id_seq OWNED BY public.api_storecategory.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: api_item id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_item ALTER COLUMN id SET DEFAULT nextval('public.api_item_id_seq'::regclass);


--
-- Name: api_store id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_store ALTER COLUMN id SET DEFAULT nextval('public.api_store_id_seq'::regclass);


--
-- Name: api_store_categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_store_categories ALTER COLUMN id SET DEFAULT nextval('public.api_store_categories_id_seq'::regclass);


--
-- Name: api_storecategory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_storecategory ALTER COLUMN id SET DEFAULT nextval('public.api_storecategory_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Data for Name: api_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_item (id, created_on, updated_on, title, image_url, description, uuid, price, store_id) FROM stdin;
1	2018-08-22 07:53:51.778491+00	2018-08-22 07:53:51.778526+00	Puliyogare		1 Bowl cooked rice fried with home made Puliyogre masala	93f4be85-b045-465c-9bda-2d06c1eebdf3	40.00	3
2	2018-08-22 07:53:51.783832+00	2018-08-22 07:53:51.783878+00	Chapati Meal	https://duyt4h9nfnj50.cloudfront.net/sku/930d4568d4e383c1b7f39f46d8462ee2	Chapati(2), Curry (2 Type), Rice (1 Bowl), Sambaar, Pickle, Salad, Curd.	8d39599a-1eae-4306-80a3-37fd43aa1238	65.00	3
3	2018-08-22 07:53:51.788801+00	2018-08-22 07:53:51.788846+00	Chapati Combo	https://duyt4h9nfnj50.cloudfront.net/sku/0f7cb005c76beab0206bd5d0ddf3f6bb	Chapati (6), Curry (2 Type), Rice (2 Bowl), Saambaar, Pickle, Salad, Curd. (Can serve 2-3 People).	7ec92faf-3614-4cd8-b6df-7af0067ec716	170.00	3
4	2018-08-22 07:53:51.792853+00	2018-08-22 07:53:51.792899+00	Rice Meal	https://duyt4h9nfnj50.cloudfront.net/sku/55a82e8831b745fc43b00f7d0a23e385	Rice (2 Bowl), Curry (2 Type), Sambaar, Pickle, Salad, Curd.	ac420ab3-3b94-4356-8d39-e6e9b509845b	65.00	3
5	2018-08-22 07:53:51.796579+00	2018-08-22 07:53:51.796626+00	Egg Fried Rice		1 Bowl of cooked rice fried with 2 Eggs and home made masala	6b136501-1aea-4b0d-99e8-881797664e04	45.00	3
6	2018-08-22 07:53:51.800446+00	2018-08-22 07:53:51.8005+00	Chapati Combo	https://duyt4h9nfnj50.cloudfront.net/sku/930d4568d4e383c1b7f39f46d8462ee2	Chapati (6), Curry (2 Type), Rice (2 Bowl), Saambaar, Pickle, Salad, Curd. (Can serve 2-3 People).	9908d486-b734-4e79-8a9f-ddc21f64d428	170.00	3
7	2018-08-22 07:53:51.804093+00	2018-08-22 07:53:51.804129+00	Rotti Meal	https://duyt4h9nfnj50.cloudfront.net/sku/d0f430656f48b6b1ce3aa3dd950fa9c9	Jowar/Jolada Rotti (2), Curry (2 Type), Rice (1 Bowl), Sambaar, Pickle, Salad, Curd.	af77acad-1525-4831-b3e3-2faeae993e37	65.00	3
8	2018-08-22 07:53:51.807761+00	2018-08-22 07:53:51.807808+00	Chapati		One piece.	da234b84-6577-4930-9a5b-05017a097b75	12.00	3
9	2018-08-22 07:53:51.81168+00	2018-08-22 07:53:51.811727+00	Puliyogare		1 Bowl cooked rice fried with home made Puliyogre masala	895bf589-a195-4df7-9a23-67505e7dacc2	40.00	3
10	2018-08-22 07:53:51.815493+00	2018-08-22 07:53:51.815538+00	Boiled Eggs		5 Eggs	8b29c866-522a-4d06-943d-b8191b4eed29	48.00	3
11	2018-08-22 07:53:51.819256+00	2018-08-22 07:53:51.819301+00	Veg Fried Rice		1 Bowl of cooked rice fried with mixed vegetables and home made masala	4cc52360-eeb1-436e-90c4-909ab8283a07	40.00	3
12	2018-08-22 07:53:51.822879+00	2018-08-22 07:53:51.822927+00	Jolad Rotti (Jowar Rotti)		Hand made authentic North Karnataka Jowar Rotti.	8a486a91-7e8b-4203-93b8-2c582b0a7c41	12.00	3
13	2018-08-22 07:53:51.82653+00	2018-08-22 07:53:51.826577+00	Rotti Meal	https://duyt4h9nfnj50.cloudfront.net/sku/d0f430656f48b6b1ce3aa3dd950fa9c9	Jowar/Jolada Rotti (2), Curry (2 Type), Rice (1 Bowl), Sambaar, Pickle, Salad, Curd.	4b8aa8d7-11e9-4a79-990e-455d3ecd017b	65.00	3
14	2018-08-22 07:53:51.830072+00	2018-08-22 07:53:51.830117+00	Egg Fried Rice		1 Bowl of cooked rice fried with 2 Eggs and home made masala	59db4628-f120-4d25-88d2-7cf9f9b4c4ca	45.00	3
15	2018-08-22 07:53:51.833644+00	2018-08-22 07:53:51.833691+00	Rice Meal	https://duyt4h9nfnj50.cloudfront.net/sku/55a82e8831b745fc43b00f7d0a23e385	Rice (2 Bowl), Curry (2 Type), Sambaar, Pickle, Salad, Curd.	e65764f1-6e3a-4954-acd8-e13e4fb3a484	65.00	3
16	2018-08-22 07:53:51.837222+00	2018-08-22 07:53:51.837266+00	Egg Fried Rice		1 Bowl of cooked rice fried with 2 Eggs and home made masala	d4d6d006-577f-41bd-af66-7a947ad2f75b	45.00	3
17	2018-08-22 07:53:51.840569+00	2018-08-22 07:53:51.840609+00	Rice Meal	https://duyt4h9nfnj50.cloudfront.net/sku/55a82e8831b745fc43b00f7d0a23e385	Rice (2 Bowl), Curry (2 Type), Sambaar, Pickle, Salad, Curd.	0e3deb48-fb91-4809-9c63-9cb5fb197188	65.00	3
18	2018-08-22 07:53:51.844109+00	2018-08-22 07:53:51.844154+00	Jeera Rice		1 Bowl of cooked rice fried with jira(CUMIN)	bbe5e205-07b3-497a-a2ad-1d98b67ae97c	40.00	3
19	2018-08-22 07:53:51.847592+00	2018-08-22 07:53:51.847637+00	Egg burji		Two eggs fried with Onion and home made masal	81886dd0-4a88-4a55-9426-00dc96fc99af	28.50	3
20	2018-08-22 07:53:51.851474+00	2018-08-22 07:53:51.851519+00	Curry 2		One bowl. (Prepared of cereals and pulses) .Sufficient for two roti or chapati.	6f036306-28d2-4713-8fc3-3fe5acaf2140	20.00	3
21	2018-08-22 07:53:51.855135+00	2018-08-22 07:53:51.85518+00	Jowar Kadak Rotti	https://duyt4h9nfnj50.cloudfront.net/sku/fca83d84b9166111afa85df7aaea5db1	One piece. (Roasted)	1f51b25c-3022-4b01-9f20-07740c427239	8.00	3
22	2018-08-22 07:53:51.859083+00	2018-08-22 07:53:51.859129+00	Rotti Combo	https://duyt4h9nfnj50.cloudfront.net/sku/930d4568d4e383c1b7f39f46d8462ee2	Jowar/Jolada Rotti (6), Curry (2 Type), Rice (2 Bowl), Saambaar, Pickle, Salad, Curd. (Can serve 2-3 People).	13bb9169-53c4-4fa5-bf3c-2493b566e387	170.00	3
23	2018-08-22 07:53:51.862879+00	2018-08-22 07:53:51.862924+00	Chapati Meal	https://duyt4h9nfnj50.cloudfront.net/sku/930d4568d4e383c1b7f39f46d8462ee2	Chapati(2), Curry (2 Type), Rice (1 Bowl), Sambaar, Pickle, Salad, Curd.	e13bbddf-99ce-4c26-a56b-7beedeed3f9e	65.00	3
24	2018-08-22 07:53:51.866651+00	2018-08-22 07:53:51.866696+00	Rotti Combo	https://duyt4h9nfnj50.cloudfront.net/sku/0f7cb005c76beab0206bd5d0ddf3f6bb	Jowar/Jolada Rotti (6), Curry (2 Type), Rice (2 Bowl), Saambaar, Pickle, Salad, Curd. (Can serve 2-3 People).	e823516d-935b-4d91-b952-1b736aab8072	170.00	3
25	2018-08-22 07:53:51.870555+00	2018-08-22 07:53:51.8706+00	Chapati Combo	https://duyt4h9nfnj50.cloudfront.net/sku/0f7cb005c76beab0206bd5d0ddf3f6bb	Chapati (6), Curry (2 Type), Rice (2 Bowl), Saambaar, Pickle, Salad, Curd. (Can serve 2-3 People).	2862d291-33a5-445d-9ed4-2803a9915059	170.00	3
26	2018-08-22 07:53:51.87466+00	2018-08-22 07:53:51.874701+00	Omelette		Two eggs	5a0e9d51-d7c2-43d4-94ba-05a8418ddadb	28.50	3
27	2018-08-22 07:53:51.878279+00	2018-08-22 07:53:51.878324+00	Veg Pulao			c287877f-ed8b-45e7-8d0b-b0fdf979c414	50.00	3
28	2018-08-22 07:53:51.882005+00	2018-08-22 07:53:51.88205+00	Egg Fried Rice		1 Bowl of cooked rice fried with 2 Eggs and home made masala	653565ab-4c39-4608-aea8-58d15a75d380	45.00	3
29	2018-08-22 07:53:51.88564+00	2018-08-22 07:53:51.885685+00	Chapati Meal	https://duyt4h9nfnj50.cloudfront.net/sku/930d4568d4e383c1b7f39f46d8462ee2	Chapati(2), Curry (2 Type), Rice (1 Bowl), Sambaar, Pickle, Salad, Curd.	a0f56f54-1e39-43de-8da0-935b38f048f2	65.00	3
30	2018-08-22 07:53:51.889135+00	2018-08-22 07:53:51.88918+00	Veg Fried Rice		1 Bowl of cooked rice fried with mixed vegetables and home made masala	41d7d379-3f00-4503-9730-0cccc9bd1ef3	40.00	3
31	2018-08-22 07:53:51.892891+00	2018-08-22 07:53:51.892938+00	Sajji Kadak Rotti (Bajra Rotti)		One piece. (Roasted)	f3739480-b954-47d6-b2b6-b7d7fecbf858	8.00	3
32	2018-08-22 07:53:51.896421+00	2018-08-22 07:53:51.896465+00	Plain Rice		White steamed rIce with Saambaar	b54a1c2b-2324-4ba1-8743-02933e040569	30.00	3
33	2018-08-22 07:53:51.899929+00	2018-08-22 07:53:51.899975+00	Lemon Rice			b9f2742a-5c8d-42ac-9b74-cad43f281321	40.00	3
34	2018-08-22 07:53:51.903671+00	2018-08-22 07:53:51.903716+00	Sambar		2cup of sambar (Sufficient for 1 bowl rice).	47bfa0c6-b16e-4266-bcee-9cede9d74506	10.00	3
35	2018-08-22 07:53:51.907621+00	2018-08-22 07:53:51.907669+00	Curd Rice		Curd RIce with Pickle	e9055f48-9525-408f-969f-d6beddb19917	40.00	3
36	2018-08-22 07:53:51.911479+00	2018-08-22 07:53:51.911525+00	Curry 1		One bowl. (Prepared of vegetables). Sufficient for two roti or chapati.	a9e6455b-9af9-4ddb-879e-3083a98a7b96	20.00	3
37	2018-08-22 07:53:51.915296+00	2018-08-22 07:53:51.91534+00	Upma (Uppittu)			0732f907-4b89-4f9e-af5e-d6973e3d3936	30.00	3
38	2018-08-22 07:53:51.919197+00	2018-08-22 07:53:51.919242+00	Upma (Uppittu)			99a3cc95-215d-4bca-9f0e-110a13e0ebe9	30.00	3
39	2018-08-22 07:53:51.922957+00	2018-08-22 07:53:51.923003+00	Puri Sabhji		3pc Poori, Aloo Sabhji along with Chutney	1ebf3e8e-f306-4e2a-b49d-4f1b7717e45e	35.00	3
40	2018-08-22 07:53:51.926716+00	2018-08-22 07:53:51.926761+00	Dosa			8cf7c88e-d351-48e4-b94b-470ee0c92248	30.00	3
41	2018-08-22 07:53:51.930558+00	2018-08-22 07:53:51.930603+00	Sabudana khichadi (Tapioca Pearls)			15ae6b19-b342-432c-ae89-cb2d930342af	30.00	3
42	2018-08-22 07:53:51.934068+00	2018-08-22 07:53:51.934113+00	Puri Sabhji		3pc Poori, Aloo Sabhji along with Chutny	f615c6bb-f96f-493e-8e5b-a836eaa99a30	35.00	3
43	2018-08-22 07:53:51.937704+00	2018-08-22 07:53:51.93775+00	Paddu			dd5fe326-27bd-42e1-ad60-3eea4123b60e	30.00	3
44	2018-08-22 07:53:51.941697+00	2018-08-22 07:53:51.941743+00	Shavige Uppittu (Vermicelli Upma)			ee1a145f-d306-421d-a9bd-8ccabdbd0f69	30.00	3
45	2018-08-22 07:53:51.945326+00	2018-08-22 07:53:51.945372+00	Boiled Eggs		5 Pc	77b9d5ef-4dce-4777-bfff-a753609f8dbe	48.00	3
46	2018-08-22 07:53:51.949912+00	2018-08-22 07:53:51.949958+00	Poha			d997bf96-28f7-46b6-9f11-3076495b69f8	30.00	3
47	2018-08-22 07:53:51.953824+00	2018-08-22 07:53:51.953868+00	Chitranna (Masala Rice)		Rice prepared with onion tadka and masala	d6d899eb-ec0d-436f-9ad8-7469baf1309f	25.00	3
48	2018-08-22 07:53:51.958123+00	2018-08-22 07:53:51.958276+00	Poha			3218ba91-71c8-4831-9b34-80c1e0dc03ce	30.00	3
49	2018-08-22 07:53:51.962056+00	2018-08-22 07:53:51.962102+00	Omelette		Two eggs.	fa03fc12-bbe2-4e6c-95f1-903d0a7bf0df	28.50	3
50	2018-08-22 08:59:52.763047+00	2018-08-22 08:59:52.763084+00	Pomegranate Milkshake			8905e737-add4-435b-8aea-a41d1ff86dfa	55.00	4
51	2018-08-22 08:59:52.767774+00	2018-08-22 08:59:52.767819+00	Mosambi Juice			171f3f15-9b04-4449-a624-d209bce7cdaf	40.00	4
52	2018-08-22 08:59:52.772119+00	2018-08-22 08:59:52.77219+00	Mosambi Solid Juice			968616e4-a038-4dfc-a569-29ef6fa22b5e	70.00	4
53	2018-08-22 08:59:52.776163+00	2018-08-22 08:59:52.776209+00	Rose Lassi			c17c108e-9436-4708-819a-40401ad79d61	55.00	4
54	2018-08-22 08:59:52.780791+00	2018-08-22 08:59:52.780835+00	Vanilla Milkshake			bef89599-e6ce-4781-9c80-927adbdcd4ac	55.00	4
55	2018-08-22 08:59:52.785131+00	2018-08-22 08:59:52.785176+00	Banana Milkshake			37ab524f-2930-4281-817b-b10e48d54bca	50.00	4
56	2018-08-22 08:59:52.789604+00	2018-08-22 08:59:52.78965+00	Apple Milkshake			a9ed5724-0863-4136-8bf1-572ac8ed0714	55.00	4
57	2018-08-22 08:59:52.793626+00	2018-08-22 08:59:52.793674+00	Grape Juice			66e1782c-4d35-4a3d-86a6-5adff3abab94	50.00	4
58	2018-08-22 08:59:52.797747+00	2018-08-22 08:59:52.797793+00	Kiwi Milkshake			2c370956-c4fc-40d2-babf-170df3af954c	70.00	4
59	2018-08-22 08:59:52.801709+00	2018-08-22 08:59:52.801755+00	Pomegranate Solid Juice			1db6913a-44da-4e86-86ba-571337ec8b26	90.00	4
60	2018-08-22 08:59:52.80574+00	2018-08-22 08:59:52.805784+00	Strawberry Milkshake			1ebb32a0-30e9-4172-b713-a2c98b6adbd2	55.00	4
61	2018-08-22 08:59:52.81132+00	2018-08-22 08:59:52.811358+00	Apple Juice			8b71a32c-4c98-4b74-9b77-2edc1bb35aeb	50.00	4
62	2018-08-22 08:59:52.81488+00	2018-08-22 08:59:52.814924+00	Chikoo Milkshake			4cb43c70-b313-4392-856e-1fbec477e70a	50.00	4
63	2018-08-22 08:59:52.818287+00	2018-08-22 08:59:52.818332+00	Butter Fruit Milkshake			4748a6d7-e283-47f1-a1f4-498cfa95b5da	60.00	4
64	2018-08-22 08:59:52.821976+00	2018-08-22 08:59:52.82202+00	Lemon Soda			124af8e2-5c58-4914-aad4-e79493099c93	30.00	4
65	2018-08-22 08:59:52.825444+00	2018-08-22 08:59:52.82549+00	Orange Juice			36164d00-9504-4092-b291-7021274b6c4f	40.00	4
66	2018-08-22 08:59:52.829069+00	2018-08-22 08:59:52.829113+00	Pineapple Juice			b1333a94-89f5-4ae0-b02c-7a4487e334e6	40.00	4
67	2018-08-22 08:59:52.832594+00	2018-08-22 08:59:52.83264+00	Mango Lassi			bc9bbae1-0236-48a8-b624-8dc4aadf4376	55.00	4
68	2018-08-22 08:59:52.836118+00	2018-08-22 08:59:52.836163+00	Muskmelon Juice			e411a870-ead9-46fd-b0c4-3e8e20146ed2	50.00	4
69	2018-08-22 08:59:52.840117+00	2018-08-22 08:59:52.840163+00	Sweetapple Milkshake			1aeb7b45-dd10-49de-86d4-c95118cd23a6	55.00	4
70	2018-08-22 08:59:52.843715+00	2018-08-22 08:59:52.843764+00	Muskmelon Milkshake			43060f5d-3cf4-4d9a-8c9e-02e13f8e2a04	55.00	4
71	2018-08-22 08:59:52.848275+00	2018-08-22 08:59:52.848314+00	Papaya Juice			313aef02-8afc-4f46-8bd1-58fbcc84a84a	40.00	4
72	2018-08-22 08:59:52.851772+00	2018-08-22 08:59:52.851817+00	Mango Milkshake			40525ba4-c54a-4661-8372-cc7b4889eced	55.00	4
73	2018-08-22 08:59:52.855416+00	2018-08-22 08:59:52.855462+00	Chocolate Milkshake			23cfb0b4-6290-4e4f-aaa8-b68be7de6b40	55.00	4
74	2018-08-22 08:59:52.85925+00	2018-08-22 08:59:52.859295+00	Vanilla Lassi			0830fbb3-d7b0-4c59-ac77-f15df03fe604	55.00	4
75	2018-08-22 08:59:52.862799+00	2018-08-22 08:59:52.862844+00	Sweet Lassi			4ac5e00b-94d6-4bbc-be32-13ac50df62de	40.00	4
76	2018-08-22 08:59:52.866389+00	2018-08-22 08:59:52.866433+00	Rose Milkshake			7a62515c-ac08-428f-8514-176779304d53	55.00	4
77	2018-08-22 08:59:52.870565+00	2018-08-22 08:59:52.870614+00	Orange Solid Juice			6a87973b-a632-4c25-b16f-a2588aa953a3	70.00	4
78	2018-08-22 08:59:52.874371+00	2018-08-22 08:59:52.874415+00	Mix Fruit Juice			1538ecbe-e23f-49a8-bdc9-c16cb8501366	60.00	4
79	2018-08-22 08:59:52.877952+00	2018-08-22 08:59:52.877996+00	Watermelon Juice			2ab7abf3-aeba-4f9b-ac15-4919a135b323	40.00	4
80	2018-08-22 08:59:52.881368+00	2018-08-22 08:59:52.881413+00	Kesar Lassi			fe4421d1-c1d7-472e-8378-44c613e28c74	70.00	4
81	2018-08-22 08:59:52.885276+00	2018-08-22 08:59:52.885321+00	Carrot Juice			5b25ab0f-0852-482c-b8de-67de29bae986	50.00	4
82	2018-08-22 08:59:52.889226+00	2018-08-22 08:59:52.889273+00	Mango Juice			835edb73-d1ed-4f2c-a40c-250139ba9043	50.00	4
83	2018-08-22 08:59:52.892762+00	2018-08-22 08:59:52.892808+00	Pomegranate Juice			0fcbc5b0-3207-44b2-94d1-7ffa481f733d	50.00	4
84	2018-08-22 08:59:52.896382+00	2018-08-22 08:59:52.896428+00	Papaya Milkshake			7b088d1c-1310-43d1-8586-eebe2be9bc0b	50.00	4
85	2018-08-22 08:59:52.899855+00	2018-08-22 08:59:52.899901+00	Strawberry Lassi			f290a1bc-be43-48f7-b34c-8f9491904775	55.00	4
86	2018-08-22 08:59:52.903506+00	2018-08-22 08:59:52.903555+00	Lemon Juice			0ba22f4e-4e14-4adb-974d-bb92e4b30eca	25.00	4
87	2018-08-22 08:59:52.907376+00	2018-08-22 08:59:52.90742+00	Kesar Milkshake			7003eaf1-8144-4e0d-ae3d-63ddc978015c	55.00	4
88	2018-08-22 08:59:52.911162+00	2018-08-22 08:59:52.911199+00	Oreo Milkshake			33353db7-0318-4497-9e89-563c3784fa0c	55.00	4
89	2018-08-22 08:59:52.91454+00	2018-08-22 08:59:52.914585+00	Cheese Pav Bhaji			2b8864d5-7b3f-44e9-98ec-ace4c486a8b1	70.00	4
90	2018-08-22 08:59:52.918039+00	2018-08-22 08:59:52.918084+00	Kachori Chaat			7c701d66-9167-4950-a057-fbd90087e4c7	60.00	4
91	2018-08-22 08:59:52.921543+00	2018-08-22 08:59:52.921591+00	Sev Puri			1ac63511-e798-4564-9aa8-09f56c970417	40.00	4
92	2018-08-22 08:59:52.924941+00	2018-08-22 08:59:52.924987+00	Aloo Puri			3bde7c0b-7cc6-4ea2-89fc-035e0e69ee05	40.00	4
93	2018-08-22 08:59:52.928518+00	2018-08-22 08:59:52.928565+00	Plain Samosa			7354f307-96fd-44b9-bb18-84fec9a0e189	20.00	4
94	2018-08-22 08:59:52.931934+00	2018-08-22 08:59:52.931978+00	Masala Pav			dbb6c72d-1467-4ae9-ae87-41391ad8a512	40.00	4
95	2018-08-22 08:59:52.935492+00	2018-08-22 08:59:52.935537+00	Papadi Chaat			b5d762d9-4d4a-4486-864e-12e4eb46cc5c	55.00	4
96	2018-08-22 08:59:52.939421+00	2018-08-22 08:59:52.939468+00	Pav Bhaji			94a45638-e0eb-4c44-a1d7-dd98d21c36b3	60.00	4
97	2018-08-22 08:59:52.942819+00	2018-08-22 08:59:52.942863+00	Masala Puri			2fe703b9-ad6a-44c9-9eb1-f91debbe2a76	40.00	4
98	2018-08-22 08:59:52.946602+00	2018-08-22 08:59:52.946647+00	Samosa Chaat			58b35d45-433b-452f-83f9-1c5142195102	60.00	4
99	2018-08-22 08:59:52.950158+00	2018-08-22 08:59:52.950202+00	Vada Pav			095f1a50-d6ce-4353-9548-8354e3dad17b	25.00	4
100	2018-08-22 08:59:52.954304+00	2018-08-22 08:59:52.954346+00	Bhel Puri			64405ffb-a03c-4de8-b8aa-c6d21523cba0	40.00	4
101	2018-08-22 08:59:52.958386+00	2018-08-22 08:59:52.958432+00	Pani Puri			9cb1528d-5e1f-4607-b542-af63b638b1c1	40.00	4
102	2018-08-22 08:59:52.961792+00	2018-08-22 08:59:52.961837+00	Dahi Puri			6e1d6e50-af1e-4b51-afcd-80ae8e2dec63	45.00	4
103	2018-08-22 08:59:52.965341+00	2018-08-22 08:59:52.965386+00	Malai Kofta			e61440a3-365f-45a1-bb24-bca76600c5d7	130.00	4
104	2018-08-22 08:59:52.969149+00	2018-08-22 08:59:52.969194+00	Kaju Masala			1a9b1f42-48d3-41c9-afb7-9dd97a496f27	140.00	4
105	2018-08-22 08:59:52.972634+00	2018-08-22 08:59:52.97268+00	Udupi Upachar Special Curry			caed6c15-102f-40cf-b613-92033cb787a7	160.00	4
106	2018-08-22 08:59:52.975861+00	2018-08-22 08:59:52.975907+00	Paneer Tikka Masala			abf05915-e2ab-47ee-bf43-cdd30f823e90	150.00	4
107	2018-08-22 08:59:52.97944+00	2018-08-22 08:59:52.979486+00	Veg Pulao			f52d7f66-1538-4567-93e5-f301b61f49a4	90.00	4
108	2018-08-22 08:59:52.983274+00	2018-08-22 08:59:52.983328+00	Veg Curry			baf9d75d-0f62-49e2-913e-bc7dbff2182b	90.00	4
109	2018-08-22 08:59:52.98706+00	2018-08-22 08:59:52.987109+00	Paneer Hyderabadi			c4dd5f0d-2c13-4c33-9d86-c1a98ca34196	130.00	4
110	2018-08-22 08:59:52.990809+00	2018-08-22 08:59:52.990853+00	Plain Palak			18c44060-6ee8-464a-986c-2a3a23af2de5	90.00	4
111	2018-08-22 08:59:52.994396+00	2018-08-22 08:59:52.994441+00	Chana Paneer			6ffb4090-a94e-4a5d-bfd3-5d56fafb68b9	100.00	4
112	2018-08-22 08:59:52.998291+00	2018-08-22 08:59:52.998336+00	Veg Makhanwala			be52b564-ab8e-48f9-880c-161c7ca10d90	105.00	4
113	2018-08-22 08:59:53.003944+00	2018-08-22 08:59:53.003992+00	Handi Biryani			e0551b23-111f-48ef-8a75-73b5b2da3be8	110.00	4
114	2018-08-22 08:59:53.007757+00	2018-08-22 08:59:53.007802+00	Mushroom Kadhai			7e1120e1-add0-42b5-8fcc-a74a454b6b5f	130.00	4
115	2018-08-22 08:59:53.011347+00	2018-08-22 08:59:53.011407+00	Butter Naan			c24dae2c-d0d5-4a5a-bfe9-366b93134bf4	35.00	4
116	2018-08-22 08:59:53.014701+00	2018-08-22 08:59:53.014747+00	Paneer Palak			68ac304d-b940-4c6d-86bc-cd06006fd5ba	130.00	4
117	2018-08-22 08:59:53.01847+00	2018-08-22 08:59:53.018514+00	Naan			03847afd-cc61-4e6e-89ef-86dcacca1ae8	30.00	4
118	2018-08-22 08:59:53.022355+00	2018-08-22 08:59:53.022401+00	Paneer Kofta			9ef0ea56-d0c4-44e4-9218-73b1450b4b75	140.00	4
119	2018-08-22 08:59:53.026001+00	2018-08-22 08:59:53.026046+00	Roti			3a8841a7-ec24-4f43-8391-a46914a9f887	25.00	4
120	2018-08-22 08:59:53.029601+00	2018-08-22 08:59:53.029645+00	Dal Fry			7c36e624-9015-4908-ace9-6f0efcfdc777	90.00	4
121	2018-08-22 08:59:53.033144+00	2018-08-22 08:59:53.033191+00	Hyderabadi Biryani			5de9d6fd-532a-4e02-a792-bcf912f85092	110.00	4
122	2018-08-22 08:59:53.037059+00	2018-08-22 08:59:53.037104+00	Veg Hyderabadi			8d8877b3-0713-4081-a2bf-e824ae0622fa	110.00	4
123	2018-08-22 08:59:53.040632+00	2018-08-22 08:59:53.040677+00	Kulcha			4a0564eb-be95-436c-a4a7-8a43aba78883	30.00	4
124	2018-08-22 08:59:53.04396+00	2018-08-22 08:59:53.044006+00	Roti Curry	https://duyt4h9nfnj50.cloudfront.net/sku/b11eecd7eac99d946b91e7b865b23b41		92544d4d-1283-4d4a-9086-dde0e92c5720	65.00	4
125	2018-08-22 08:59:53.047409+00	2018-08-22 08:59:53.047453+00	Mushroom Masala			61d29ab6-f087-4b50-8539-34d3f4cb3ca5	130.00	4
126	2018-08-22 08:59:53.050845+00	2018-08-22 08:59:53.05089+00	Roti Curry	https://duyt4h9nfnj50.cloudfront.net/sku/b11eecd7eac99d946b91e7b865b23b41		a534f79b-5636-4c15-905b-00d7fe9cbdf0	65.00	4
127	2018-08-22 08:59:53.054459+00	2018-08-22 08:59:53.054506+00	Butter Roti			91de2780-9340-449e-b169-bb4917442d5d	30.00	4
128	2018-08-22 08:59:53.059042+00	2018-08-22 08:59:53.059087+00	Kaju Paneer			ee34a8ff-ffd5-48c5-be23-4118e7981d0d	150.00	4
129	2018-08-22 08:59:53.063609+00	2018-08-22 08:59:53.063654+00	Paneer Kadhai			845eb4d0-22db-4ee3-ba50-0d9a427e1e57	140.00	4
130	2018-08-22 08:59:53.067799+00	2018-08-22 08:59:53.067844+00	Paneer Butter Masala			67e46519-4eac-4e3f-8432-b98e58a96f2a	130.00	4
131	2018-08-22 08:59:53.071887+00	2018-08-22 08:59:53.071948+00	Mix Veg Kadhai			bd4958c2-cd91-4cf0-82a2-68928918ec79	110.00	4
132	2018-08-22 08:59:53.076093+00	2018-08-22 08:59:53.076139+00	Green Peas Masala			fa351cc8-611d-4ea7-9a88-00992fac569b	90.00	4
133	2018-08-22 08:59:53.080066+00	2018-08-22 08:59:53.080111+00	Veg Kolhapuri			5ef55e9d-beee-43fc-b59f-c2992a703310	105.00	4
134	2018-08-22 08:59:53.084007+00	2018-08-22 08:59:53.084052+00	Aloo Paratha			4471fb57-ac8e-4d0b-b594-9e2810d56a70	50.00	4
135	2018-08-22 08:59:53.088062+00	2018-08-22 08:59:53.088107+00	Dal Tadka			bcb3893c-c210-41a9-a5dc-1a29444fabb6	95.00	4
136	2018-08-22 08:59:53.092089+00	2018-08-22 08:59:53.092135+00	Butter Kulcha			a3fef82e-97c3-4859-bcae-75c644820e65	35.00	4
137	2018-08-22 08:59:53.096049+00	2018-08-22 08:59:53.096093+00	Aloo Matar			738133c0-176e-486a-974e-0159b0588c36	90.00	4
138	2018-08-22 08:59:53.100012+00	2018-08-22 08:59:53.100056+00	Udupi Upachar Special Pulao			61274077-34e7-4a64-a823-29417ebc24a9	130.00	4
139	2018-08-22 08:59:53.103964+00	2018-08-22 08:59:53.104009+00	Veg Biryani			a4c8602d-1cab-47a6-ba2c-c0449e4ea196	100.00	4
140	2018-08-22 08:59:53.108229+00	2018-08-22 08:59:53.108274+00	Chana Masala			e3682c08-659d-4ba9-9621-4dedd19b7c21	90.00	4
141	2018-08-22 08:59:53.112298+00	2018-08-22 08:59:53.112344+00	Dal Palak			b189c1fe-57ca-4864-8a4f-c8eac77c4a73	100.00	4
142	2018-08-22 08:59:53.116463+00	2018-08-22 08:59:53.116507+00	Aloo Palak			0a876f2d-aab6-43bb-b549-b2e3bbc5b57e	100.00	4
143	2018-08-22 08:59:53.120616+00	2018-08-22 08:59:53.12066+00	Paneer Matar			a8d29613-efbc-480f-a2f3-971dc4e3a63d	100.00	4
144	2018-08-22 08:59:53.125019+00	2018-08-22 08:59:53.125064+00	Veg Kofta			2dffd618-2464-4938-a540-81b1416a9e24	110.00	4
145	2018-08-22 08:59:53.129023+00	2018-08-22 08:59:53.129068+00	Veg Pepper Masala			afa24719-92b0-458a-81e8-7345d0c02a55	110.00	4
146	2018-08-22 08:59:53.132966+00	2018-08-22 08:59:53.133011+00	Singapore Noodles			6dbfde23-4892-408e-aeee-efc6222b6210	110.00	4
147	2018-08-22 08:59:53.136987+00	2018-08-22 08:59:53.137036+00	Paneer Noodles			6ac3591e-c640-4fdc-8c59-82928d13f88c	100.00	4
148	2018-08-22 08:59:53.141181+00	2018-08-22 08:59:53.141225+00	Mushroom Pepper Dry			c82b961f-d9f7-4cd5-a342-f239b89aacb1	105.00	4
149	2018-08-22 08:59:53.145098+00	2018-08-22 08:59:53.145143+00	Udupi Upachar Special Fried Rice			d50863f6-8adb-400d-8843-2895a01778d0	110.00	4
150	2018-08-22 08:59:53.149023+00	2018-08-22 08:59:53.149068+00	Baby Corn Chilli			43177b8d-25d1-40b4-8d8c-a103e35cca80	90.00	4
151	2018-08-22 08:59:53.153563+00	2018-08-22 08:59:53.153609+00	Singapore Fried Rice			ec9f6848-65a3-4677-979d-4896508c93a2	110.00	4
152	2018-08-22 08:59:53.158113+00	2018-08-22 08:59:53.158159+00	Schezwan Noodles			121ee019-3c03-494f-99e2-3005d2376ba1	100.00	4
153	2018-08-22 08:59:53.161995+00	2018-08-22 08:59:53.16204+00	Mushroom Manchurian			30aa69e9-1214-4051-82b6-a36f7104025e	90.00	4
154	2018-08-22 08:59:53.165947+00	2018-08-22 08:59:53.165991+00	Paneer Pepper Dry			3a0f3d84-e90a-443f-bd57-e40d4c060f02	110.00	4
155	2018-08-22 08:59:53.169801+00	2018-08-22 08:59:53.169837+00	Mushroom Chilli			8a3c6da4-d7b9-42da-9426-552b9491bdb3	90.00	4
156	2018-08-22 08:59:53.173837+00	2018-08-22 08:59:53.173884+00	Paneer Fried Rice			8849c5c9-1a2d-4fae-ab93-0a3661aef882	100.00	4
157	2018-08-22 08:59:53.177807+00	2018-08-22 08:59:53.177853+00	Mushroom Noodles			5097c373-01bb-4ed7-aafe-74993f2e4c94	90.00	4
158	2018-08-22 08:59:53.181642+00	2018-08-22 08:59:53.181685+00	Mushroom Fried Rice			d33c59b8-dc06-4bf1-93ec-6029b4fe7be6	90.00	4
159	2018-08-22 08:59:53.1856+00	2018-08-22 08:59:53.185644+00	Gobi 65			bf8d062f-a4f7-4de7-bfe1-626ab61f8454	90.00	4
160	2018-08-22 08:59:53.189644+00	2018-08-22 08:59:53.18969+00	Ghee Rice			3c8b3ded-90b0-4fd4-862d-9f9b2a603288	80.00	4
161	2018-08-22 08:59:53.193734+00	2018-08-22 08:59:53.19377+00	Baby Corn Pepper Dry			5e195caf-63e2-4715-898b-67ad33f6bc73	100.00	4
162	2018-08-22 08:59:53.19772+00	2018-08-22 08:59:53.197765+00	Baby Corn Manchurian			3440f1bb-99eb-4f92-8bec-9a71b12fc49f	90.00	4
163	2018-08-22 08:59:53.201582+00	2018-08-22 08:59:53.201627+00	Veg Noodles			5de25fb3-2a53-4dd4-8182-9e26cc22f461	80.00	4
164	2018-08-22 08:59:53.205701+00	2018-08-22 08:59:53.205752+00	Paneer 65			b7cea6e0-e265-475e-9619-a50135858f8f	130.00	4
165	2018-08-22 08:59:53.209737+00	2018-08-22 08:59:53.209781+00	Paneer Chilli			4710599c-3430-4a04-8fd6-834b53bdcbcc	110.00	4
166	2018-08-22 08:59:53.213838+00	2018-08-22 08:59:53.213884+00	Mushroom 65			1f7cbe2c-f39c-489c-81a8-ba02fe281f3f	100.00	4
167	2018-08-22 08:59:53.218154+00	2018-08-22 08:59:53.2182+00	Gobi Manchurian			5dec8e32-41d3-4230-adcf-8a4a5caf1d68	80.00	4
168	2018-08-22 08:59:53.222569+00	2018-08-22 08:59:53.222608+00	Schezwan Fried Rice			fb34fc87-2417-4307-bdc0-6d3ab66730b0	100.00	4
169	2018-08-22 08:59:53.226363+00	2018-08-22 08:59:53.226403+00	Paneer Manchurian			ae40e7e7-816f-4773-a866-98ce2d230be3	110.00	4
170	2018-08-22 08:59:53.229845+00	2018-08-22 08:59:53.229881+00	Gobi Chilli			87e0c529-cf09-4d75-acd6-4652a34ac8cb	85.00	4
171	2018-08-22 08:59:53.233245+00	2018-08-22 08:59:53.23328+00	Baby Corn 65			85e3660c-9677-4551-96f6-63718e036efa	100.00	4
172	2018-08-22 08:59:53.236701+00	2018-08-22 08:59:53.236738+00	Veg Fried Rice			7a66dfb3-17eb-4059-ac48-7882722a3c72	80.00	4
173	2018-08-22 08:59:53.240851+00	2018-08-22 08:59:53.240981+00	Jeera Rice			3e0b4b5d-3c01-44a8-8de9-ce5c09078b1b	80.00	4
174	2018-08-22 08:59:53.244701+00	2018-08-22 08:59:53.244751+00	Puri			b44e339b-4ae9-49ac-8b9d-8995868bc9ab	50.00	4
175	2018-08-22 08:59:53.24873+00	2018-08-22 08:59:53.248771+00	Paper Plain Dosa			d1e8ae68-64cb-439b-9e3d-d0a5ea998789	50.00	4
176	2018-08-22 08:59:53.252477+00	2018-08-22 08:59:53.252513+00	Avalakki Bhath			e5fd2f50-5ea9-4a1d-a61e-90d3b5ed301e	40.00	4
177	2018-08-22 08:59:53.256123+00	2018-08-22 08:59:53.256192+00	Plain Dosa			226c5874-ed53-4aef-9482-c9c4104d0468	40.00	4
178	2018-08-22 08:59:53.260272+00	2018-08-22 08:59:53.260347+00	Chow Chow Bhath	https://duyt4h9nfnj50.cloudfront.net/sku/d3fbec62c72e991a6e1cf83bb4bcd9c0		42d1f70d-b59a-4b1f-86c5-20dd8ae232d3	50.00	4
179	2018-08-22 08:59:53.264192+00	2018-08-22 08:59:53.264233+00	Masala Dosa	https://duyt4h9nfnj50.cloudfront.net/sku/55893713323c7cb1e8f904915cec7c13		527525a8-5172-4b5c-802b-0ae299cb546e	50.00	4
180	2018-08-22 08:59:53.267751+00	2018-08-22 08:59:53.26779+00	Neer Dosa			49d9cb4c-4d70-42cd-bd48-bcc8529c3772	60.00	4
181	2018-08-22 08:59:53.271368+00	2018-08-22 08:59:53.271444+00	Rava Dosa			4a5122cc-6e34-4233-9a26-8ed8432623ce	55.00	4
182	2018-08-22 08:59:53.27579+00	2018-08-22 08:59:53.275842+00	Meals			8bdf24d4-71be-433f-988f-2ce3d433aecf	65.00	4
183	2018-08-22 08:59:53.279951+00	2018-08-22 08:59:53.280013+00	Mini Meals			6df9ea00-95bf-41e8-a2a1-be156972b4e2	50.00	4
184	2018-08-22 08:59:53.284003+00	2018-08-22 08:59:53.284049+00	Shavige Bhath			3a7a0134-190c-4fe0-86f6-86d9f3a43fb6	45.00	4
185	2018-08-22 08:59:53.28784+00	2018-08-22 08:59:53.287887+00	Vada		1 piece.	44cabc8d-e8ed-44f7-93cf-efe138c5c1e7	25.00	4
186	2018-08-22 08:59:53.291666+00	2018-08-22 08:59:53.291713+00	Rava Idli			28dfe1e4-bb1e-4dad-98a0-0e732aedd404	35.00	4
187	2018-08-22 08:59:53.295337+00	2018-08-22 08:59:53.295381+00	Special Masala Dosa			49913dd1-2482-4202-bd2c-1b210ee7a9c6	60.00	4
188	2018-08-22 08:59:53.298891+00	2018-08-22 08:59:53.298938+00	Dahi Vada			870b049f-ef30-4cc7-90e1-a31080d6ad63	40.00	4
189	2018-08-22 08:59:53.302372+00	2018-08-22 08:59:53.302417+00	Open Dosa			c0bfc60e-a775-45c4-845c-6b47f59221b4	55.00	4
190	2018-08-22 08:59:53.305929+00	2018-08-22 08:59:53.30598+00	Bajji			44aec04d-2d2f-42bb-b98b-a805f0e542c4	35.00	4
191	2018-08-22 08:59:53.309821+00	2018-08-22 08:59:53.309867+00	Paper Masala Dosa			a6fdb788-98e9-4907-b837-b2b6678f3281	60.00	4
192	2018-08-22 08:59:53.314417+00	2018-08-22 08:59:53.314462+00	1 Idli and 1 Vada			66328df5-055c-4161-abfc-46148f81a993	40.00	4
193	2018-08-22 08:59:53.31835+00	2018-08-22 08:59:53.318396+00	Ragi Dosa			3e4b399d-3601-47f9-8940-f5a6884bc3a3	60.00	4
194	2018-08-22 08:59:53.322+00	2018-08-22 08:59:53.322047+00	Onion Dosa			dcb53713-76d3-477f-94d1-cf4d22f85985	55.00	4
195	2018-08-22 08:59:53.325824+00	2018-08-22 08:59:53.325869+00	Curd Rice			2dfef76b-6dfb-4506-8eff-46e96b69425f	40.00	4
196	2018-08-22 08:59:53.329346+00	2018-08-22 08:59:53.329391+00	Rava Onion Dosa			950bd130-4806-46f8-822b-4a9172b4c7dc	60.00	4
197	2018-08-22 08:59:53.333105+00	2018-08-22 08:59:53.333149+00	Bonda Soup			29fd8d96-bc2e-4786-8957-7e175dce88a3	35.00	4
198	2018-08-22 08:59:53.336691+00	2018-08-22 08:59:53.336728+00	Pakoda			6e53e4da-5c20-426d-a46d-0f2aafed1597	35.00	4
199	2018-08-22 08:59:53.34015+00	2018-08-22 08:59:53.340197+00	2 Idli and 1 Vada	https://duyt4h9nfnj50.cloudfront.net/sku/dec5a0aae68bc3382ded82357f66938b		436c5e4b-bccd-4a4d-9a71-ebbaadc54032	50.00	4
200	2018-08-22 08:59:53.343574+00	2018-08-22 08:59:53.343621+00	Chow Chow Bhath	https://duyt4h9nfnj50.cloudfront.net/sku/d3fbec62c72e991a6e1cf83bb4bcd9c0		8e7e4f5e-a6e3-432f-8c34-0df8372d362a	50.00	4
201	2018-08-22 08:59:53.347214+00	2018-08-22 08:59:53.347259+00	2 Idli and 1 Vada	https://duyt4h9nfnj50.cloudfront.net/sku/dec5a0aae68bc3382ded82357f66938b		e2072eae-3131-4265-98cd-286497030ffd	50.00	4
202	2018-08-22 08:59:53.350998+00	2018-08-22 08:59:53.351045+00	Rava Masala Dosa			503ac704-1669-413a-99f7-a28cdfcc0f77	60.00	4
203	2018-08-22 08:59:53.355152+00	2018-08-22 08:59:53.3552+00	Rice Bhath			bc5dd335-1f0d-45b9-b94d-2b96d03ae071	45.00	4
204	2018-08-22 08:59:53.358962+00	2018-08-22 08:59:53.359008+00	Set Dosa			5319b44d-0565-4c16-bc9f-9d31c02e2802	50.00	4
205	2018-08-22 08:59:53.362671+00	2018-08-22 08:59:53.362715+00	Kesari Bhath			ce2067b0-feea-4bbb-b140-7ece8aa4b21e	25.00	4
206	2018-08-22 08:59:53.366178+00	2018-08-22 08:59:53.366222+00	Idli			113930d2-2452-45f3-ac02-774dcfef49ea	15.00	4
207	2018-08-22 08:59:53.369867+00	2018-08-22 08:59:53.369914+00	Masala Dosa	https://duyt4h9nfnj50.cloudfront.net/sku/55893713323c7cb1e8f904915cec7c13		a5439e3f-ebc2-4eaa-b501-258e3f43d713	50.00	4
\.


--
-- Data for Name: api_store; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_store (id, created_on, updated_on, uuid, title, hero_image_url, location, city, currency) FROM stdin;
3	2018-08-22 07:53:51.692463+00	2018-08-22 07:53:51.692503+00	1f7228e3-f6b3-4be3-bea9-b4e48dae8b9e	DELIBOX	https://duyt4h9nfnj50.cloudfront.net/resized/1534505110921-w550-6c.jpg	{"address": {"city": "Bengaluru", "region": "KA", "country": "IN", "address1": "263, Indira Akash Apartment, 21st Main Road, 3rd D Cross Rd, BTM 2nd Stage, Kuvempu Nagar, Stage 2, BTM 2nd Stage, Bengaluru, Karnataka 560076, India", "aptOrSuite": "#11, 3rd E Cross", "postalCode": "560076", "formattedAddress": "263, Indira Akash Apartment, 21st Main Road, 3rd D Cross Rd, Btm 2nd Stage, Kuvempu Nagar, Stage 2, Btm 2nd Stage, Bengaluru, KarnataKA 560076"}, "latitude": 12.913032402118816, "longitude": 77.61180130765828}	Bangalore	INR
4	2018-08-22 08:59:52.531791+00	2018-08-22 08:59:52.53183+00	5d89c77d-8d84-4811-8189-c5ba5167734a	Udupi Upachar	https://duyt4h9nfnj50.cloudfront.net/resized/7b7e704003bb7b5cc0093aed6ab55e93-w550-c3.jpg	{"address": {"city": "Bengaluru", "region": "KA", "country": "IN", "address1": "HOTEL UDUPI UPACHAR", "aptOrSuite": "", "postalCode": "560078", "formattedAddress": "Hotel Udupi Upachar, Bengaluru, KA 560078"}, "latitude": 12.903272, "longitude": 77.591751}	Bangalore	INR
\.


--
-- Data for Name: api_store_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_store_categories (id, store_id, storecategory_id) FROM stdin;
3	3	10
4	4	11
5	4	12
6	4	13
\.


--
-- Data for Name: api_storecategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_storecategory (id, created_on, updated_on, name, key, uuid) FROM stdin;
10	2018-08-22 07:53:51.608425+00	2018-08-22 07:53:51.608476+00	South Indian	SouthIndian	cb103566-43e5-4a78-aa8a-6102e2f7bb56
11	2018-08-22 08:59:52.44845+00	2018-08-22 08:59:52.448498+00	South Indian	SouthIndian	32c4cc70-7e5b-45ab-bb13-ee7f6258a39e
12	2018-08-22 08:59:52.453728+00	2018-08-22 08:59:52.453775+00	North Indian	NorthIndian	21467006-3fb8-44b6-a5f0-d74b275e7652
13	2018-08-22 08:59:52.457098+00	2018-08-22 08:59:52.457143+00	Chinese	Chinese	afb19f46-aafb-4ef4-ae8f-ac08893a2b53
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add user	4	add_user
14	Can change user	4	change_user
15	Can delete user	4	delete_user
16	Can view user	4	view_user
17	Can add content type	5	add_contenttype
18	Can change content type	5	change_contenttype
19	Can delete content type	5	delete_contenttype
20	Can view content type	5	view_contenttype
21	Can add session	6	add_session
22	Can change session	6	change_session
23	Can delete session	6	delete_session
24	Can view session	6	view_session
25	Can add item	7	add_item
26	Can change item	7	change_item
27	Can delete item	7	delete_item
28	Can view item	7	view_item
29	Can add store	8	add_store
30	Can change store	8	change_store
31	Can delete store	8	delete_store
32	Can view store	8	view_store
33	Can add store category	9	add_storecategory
34	Can change store category	9	change_storecategory
35	Can delete store category	9	delete_storecategory
36	Can view store category	9	view_storecategory
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	api	item
8	api	store
9	api	storecategory
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2018-08-22 05:25:26.902109+00
2	auth	0001_initial	2018-08-22 05:25:27.062015+00
3	admin	0001_initial	2018-08-22 05:25:27.106791+00
4	admin	0002_logentry_remove_auto_add	2018-08-22 05:25:27.122881+00
5	admin	0003_logentry_add_action_flag_choices	2018-08-22 05:25:27.138165+00
6	api	0001_initial	2018-08-22 05:25:27.264552+00
7	contenttypes	0002_remove_content_type_name	2018-08-22 05:25:27.320793+00
8	auth	0002_alter_permission_name_max_length	2018-08-22 05:25:27.346462+00
9	auth	0003_alter_user_email_max_length	2018-08-22 05:25:27.373385+00
10	auth	0004_alter_user_username_opts	2018-08-22 05:25:27.390152+00
11	auth	0005_alter_user_last_login_null	2018-08-22 05:25:27.411868+00
12	auth	0006_require_contenttypes_0002	2018-08-22 05:25:27.419177+00
13	auth	0007_alter_validators_add_error_messages	2018-08-22 05:25:27.436231+00
14	auth	0008_alter_user_username_max_length	2018-08-22 05:25:27.462113+00
15	auth	0009_alter_user_last_name_max_length	2018-08-22 05:25:27.486157+00
16	sessions	0001_initial	2018-08-22 05:25:27.519762+00
34	api	0002_auto_20180822_0748	2018-08-22 07:48:29.576528+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.


--
-- Name: api_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_item_id_seq', 207, true);


--
-- Name: api_store_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_store_categories_id_seq', 6, true);


--
-- Name: api_store_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_store_id_seq', 4, true);


--
-- Name: api_storecategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_storecategory_id_seq', 13, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 66, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, false);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 33, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 34, true);


--
-- Name: api_item api_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_item
    ADD CONSTRAINT api_item_pkey PRIMARY KEY (id);


--
-- Name: api_store_categories api_store_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_store_categories
    ADD CONSTRAINT api_store_categories_pkey PRIMARY KEY (id);


--
-- Name: api_store_categories api_store_categories_store_id_storecategory_id_d208f998_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_store_categories
    ADD CONSTRAINT api_store_categories_store_id_storecategory_id_d208f998_uniq UNIQUE (store_id, storecategory_id);


--
-- Name: api_store api_store_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_store
    ADD CONSTRAINT api_store_pkey PRIMARY KEY (id);


--
-- Name: api_storecategory api_storecategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_storecategory
    ADD CONSTRAINT api_storecategory_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: api_item_store_id_76637ef5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_item_store_id_76637ef5 ON public.api_item USING btree (store_id);


--
-- Name: api_store_categories_store_id_5ea8a6e8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_store_categories_store_id_5ea8a6e8 ON public.api_store_categories USING btree (store_id);


--
-- Name: api_store_categories_storecategory_id_96358548; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_store_categories_storecategory_id_96358548 ON public.api_store_categories USING btree (storecategory_id);


--
-- Name: api_store_uuid_45483fdc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_store_uuid_45483fdc ON public.api_store USING btree (uuid);


--
-- Name: api_store_uuid_45483fdc_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_store_uuid_45483fdc_like ON public.api_store USING btree (uuid varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: api_item api_item_store_id_76637ef5_fk_api_store_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_item
    ADD CONSTRAINT api_item_store_id_76637ef5_fk_api_store_id FOREIGN KEY (store_id) REFERENCES public.api_store(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_store_categories api_store_categories_store_id_5ea8a6e8_fk_api_store_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_store_categories
    ADD CONSTRAINT api_store_categories_store_id_5ea8a6e8_fk_api_store_id FOREIGN KEY (store_id) REFERENCES public.api_store(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_store_categories api_store_categories_storecategory_id_96358548_fk_api_store; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_store_categories
    ADD CONSTRAINT api_store_categories_storecategory_id_96358548_fk_api_store FOREIGN KEY (storecategory_id) REFERENCES public.api_storecategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

